import { Component } from '@angular/core';

@Component({
  selector: 'app-travelled',
  templateUrl: './travelled.component.html',
  styleUrls: ['./travelled.component.css']
})
export class TravelledComponent {

}
