import { IOpinion } from "./iopinion"

export interface IOpinions {
    options: Array<IOpinion>
}
