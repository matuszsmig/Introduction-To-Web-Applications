import { Trip } from "./trip";

export interface Trips {
    options: Array<Trip>
}
