export interface IOpinion {
    nick: string;
    title: string;
    opinion: string;
    begins: string;
}
